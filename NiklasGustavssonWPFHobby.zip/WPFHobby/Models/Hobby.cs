﻿using System;

namespace WPFHobby.Models
{
    public class Hobby
    {
        public string Title { get; set; } = null!;
        public DateTime Date { get; set; }
    }
}
